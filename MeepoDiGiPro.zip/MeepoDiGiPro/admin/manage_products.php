<?php
include '../db.php';
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

if (isset($_POST['add_product'])) {
    $nama = $conn->real_escape_string($_POST['nama']);
    $harga = (int)$_POST['harga'];
    $diskon = (int)$_POST['diskon'];
    $gambar = $_FILES['gambar']['name'];

    move_uploaded_file($_FILES['gambar']['tmp_name'], "../assets/images/products/" . $gambar);

    $conn->query("INSERT INTO products (nama, harga, diskon, gambar) VALUES ('$nama', '$harga', '$diskon', '$gambar')");

    echo "<script>alert('Produk berhasil ditambahkan!'); window.location='manage_products.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Manajemen Produk</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50 p-8">

<h1 class="text-3xl font-bold mb-6">Tambah Produk Baru</h1>

<form method="POST" enctype="multipart/form-data" class="space-y-4 bg-white p-6 rounded shadow w-full md:w-1/2">
  <div>
    <label class="block font-semibold mb-1">Nama Produk</label>
    <input type="text" name="nama" class="w-full p-2 border rounded" required>
  </div>
  <div>
    <label class="block font-semibold mb-1">Harga</label>
    <input type="number" name="harga" class="w-full p-2 border rounded" required>
  </div>
  <div>
    <label class="block font-semibold mb-1">Diskon (%)</label>
    <input type="number" name="diskon" class="w-full p-2 border rounded">
  </div>
  <div>
    <label class="block font-semibold mb-1">Gambar Produk</label>
    <input type="file" name="gambar" class="w-full p-2 border rounded" required>
  </div>
  <button type="submit" name="add_product" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded">Tambah Produk</button>
</form>

</body>
</html>
