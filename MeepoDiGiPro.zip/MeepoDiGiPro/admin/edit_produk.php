<?php
session_start();
include '../db.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: manage_missions.php');
    exit;
}

$id = intval($_GET['id']);
$product = $conn->query("SELECT * FROM products WHERE id=$id")->fetch_assoc();

if (isset($_POST['submit'])) {
    $nama = $conn->real_escape_string($_POST['nama']);
    $harga = (int)$_POST['harga'];
    $diskon = (int)$_POST['diskon'];
    $deskripsi = $conn->real_escape_string($_POST['deskripsi']);
    $rating = (int)$_POST['rating'];
    $status = $conn->real_escape_string($_POST['status']);

    $update_gambar = "";
    if (!empty($_FILES['gambar']['name'])) {
        $gambar = $_FILES['gambar']['name'];
        $tmp = $_FILES['gambar']['tmp_name'];

        $ext = strtolower(pathinfo($gambar, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $new_name = uniqid().".".$ext;

        if (in_array($ext, $allowed)) {
            move_uploaded_file($tmp, "../uploads/produk/$new_name");
            $update_gambar = ", gambar='$new_name'";
        } else {
            echo "<script>alert('Format gambar tidak didukung!');</script>";
        }
    }

    $conn->query("UPDATE products SET nama='$nama', harga='$harga', diskon='$diskon', deskripsi='$deskripsi', rating='$rating', status='$status' $update_gambar WHERE id=$id");

    echo "<script>alert('Produk berhasil diupdate!'); window.location='manage_missions.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Produk</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

<?php include 'sidebar.php'; ?>

<div class="main-content">
    <h1>Edit Produk</h1>

    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="nama" value="<?= htmlspecialchars($product['nama']) ?>" required><br><br>
        <input type="number" name="harga" value="<?= $product['harga'] ?>" required><br><br>
        <input type="number" name="diskon" value="<?= $product['diskon'] ?>"><br><br>
        <input type="number" name="rating" value="<?= $product['rating'] ?>"><br><br>
        <textarea name="deskripsi" required><?= htmlspecialchars($product['deskripsi']) ?></textarea><br><br>
        <select name="status">
            <option value="aktif" <?= $product['status'] == 'aktif' ? 'selected' : '' ?>>Aktif</option>
            <option value="nonaktif" <?= $product['status'] == 'nonaktif' ? 'selected' : '' ?>>Non Aktif</option>
        </select><br><br>
        <label>Ganti Gambar:</label><br>
        <input type="file" name="gambar"><br><br>
        <button type="submit" name="submit">Update</button>
    </form>
</div>

</body>
</html>
