<div class="sidebar">
    <h2>MeepoDiGiPro</h2>
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="manage_users.php">Kelola Pengguna</a></li>
        <li><a href="manage_missions.php">Kelola Produk/Misi</a></li>
        <li><a href="manage_withdraw.php">Kelola Withdraw</a></li>
        <li><a href="manage_referral.php">Data Referral</a></li>
        <li><a href="settings.php">Pengaturan</a></li>
        <li><a href="logout.php" class="logout">Logout</a></li>
    </ul>
</div>
