<?php
include '../db.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$id = intval($_GET['id']);

// Update status withdraw
$conn->query("UPDATE withdraws SET status='approved' WHERE id=$id");

echo "<script>alert('Withdraw disetujui!'); window.location='manage_withdraw.php';</script>";
