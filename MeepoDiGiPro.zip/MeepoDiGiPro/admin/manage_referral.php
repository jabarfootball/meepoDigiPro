<?php
session_start();
include '../db.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$referrals = $conn->query("SELECT * FROM users WHERE referred_by IS NOT NULL");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Referral - Admin</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

<?php include 'sidebar.php'; ?>

<div class="main-content">
    <h1>Data Referral</h1>

    <table>
        <tr>
            <th>Username</th>
            <th>Direferensikan Oleh</th>
        </tr>
        <?php while($r = $referrals->fetch_assoc()): ?>
        <?php
            $referrer = $conn->query("SELECT username FROM users WHERE referral_code='".$r['referred_by']."'")->fetch_assoc();
        ?>
        <tr>
            <td><?= htmlspecialchars($r['username']) ?></td>
            <td><?= htmlspecialchars($referrer['username']) ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

</div>

</body>
</html>
