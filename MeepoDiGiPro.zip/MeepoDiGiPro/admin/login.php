<?php
session_start();
include '../db.php';

// Jika sudah login, langsung masuk
if (isset($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

// Proses login admin
if (isset($_POST['login'])) {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    $check = $conn->query("SELECT * FROM admins WHERE username='$username' LIMIT 1");

    if ($check->num_rows > 0) {
        $admin = $check->fetch_assoc();
        if (password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            header('Location: dashboard.php');
            exit;
        }
    }

    $error = "Username atau Password salah!";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login Admin - MeepoDiGiPro</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

<div class="login-container">
    <h1>Admin Login</h1>

    <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>

    <form method="POST">
        <input type="text" name="username" placeholder="Username Admin" required><br><br>
        <input type="password" name="password" placeholder="Password" required><br><br>
        <button type="submit" name="login">Login</button>
    </form>
</div>

</body>
</html>
