<?php
session_start();
include '../db.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$withdraws = $conn->query("SELECT * FROM withdraws WHERE status='pending' ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Withdraw - Admin</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

<?php include 'sidebar.php'; ?>

<div class="main-content">
    <h1>Permintaan Withdraw</h1>

    <table>
        <tr>
            <th>Username</th>
            <th>Jumlah</th>
            <th>Bank Tujuan</th>
            <th>Aksi</th>
        </tr>
        <?php while($w = $withdraws->fetch_assoc()): ?>
        <?php
            $user = $conn->query("SELECT username, bank_account FROM users WHERE id=".$w['user_id'])->fetch_assoc();
        ?>
        <tr>
            <td><?= htmlspecialchars($user['username']) ?></td>
            <td>Rp <?= number_format($w['amount']) ?></td>
            <td><?= htmlspecialchars($user['bank_account']) ?></td>
            <td>
                <a href="approve_withdraw.php?id=<?= $w['id'] ?>">Approve</a> |
                <a href="reject_withdraw.php?id=<?= $w['id'] ?>">Reject</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

</div>

</body>
</html>
