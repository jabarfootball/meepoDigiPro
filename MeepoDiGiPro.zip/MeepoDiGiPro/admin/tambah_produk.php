<?php
session_start();
include '../db.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

if (isset($_POST['submit'])) {
    $nama = $conn->real_escape_string($_POST['nama']);
    $harga = (int)$_POST['harga'];
    $diskon = (int)$_POST['diskon'];
    $deskripsi = $conn->real_escape_string($_POST['deskripsi']);
    $rating = (int)$_POST['rating'];

    // Upload gambar
    $gambar = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];

    $ext = strtolower(pathinfo($gambar, PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'gif'];
    $new_name = uniqid().".".$ext;

    if (in_array($ext, $allowed)) {
        move_uploaded_file($tmp, "../uploads/produk/$new_name");

        // Simpan ke database
        $conn->query("INSERT INTO products (nama, harga, diskon, deskripsi, rating, gambar) VALUES ('$nama', '$harga', '$diskon', '$deskripsi', '$rating', '$new_name')");

        echo "<script>alert('Produk berhasil ditambahkan!'); window.location='manage_missions.php';</script>";
    } else {
        echo "<script>alert('Format gambar tidak didukung!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Produk</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

<?php include 'sidebar.php'; ?>

<div class="main-content">
    <h1>Tambah Produk Baru</h1>

    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="nama" placeholder="Nama Produk" required><br><br>
        <input type="number" name="harga" placeholder="Harga" required><br><br>
        <input type="number" name="diskon" placeholder="Diskon (%)" value="0"><br><br>
        <input type="number" name="rating" placeholder="Rating (1-5)" value="5"><br><br>
        <textarea name="deskripsi" placeholder="Deskripsi Produk" required></textarea><br><br>
        <input type="file" name="gambar" required><br><br>
        <button type="submit" name="submit">Simpan</button>
    </form>
</div>

</body>
</html>
