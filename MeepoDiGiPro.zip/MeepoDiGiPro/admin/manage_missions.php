<?php
session_start();
include '../db.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$missions = $conn->query("SELECT * FROM products ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Produk/Misi - Admin</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

<?php include 'sidebar.php'; ?>

<div class="main-content">
    <h1>Kelola Produk / Misi</h1>

    <a href="tambah_produk.php" class="btn">+ Tambah Produk Baru</a>

    <table>
        <tr>
            <th>Nama</th>
            <th>Harga</th>
            <th>Diskon (%)</th>
            <th>Rating</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
        <?php while($m = $missions->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($m['nama']) ?></td>
            <td>Rp <?= number_format($m['harga']) ?></td>
            <td><?= $m['diskon'] ?>%</td>
            <td><?= $m['rating'] ?>/5</td>
            <td><?= $m['status'] ?></td>
            <td><a href="edit_produk.php?id=<?= $m['id'] ?>">Edit</a></td>
        </tr>
        <?php endwhile; ?>
    </table>

</div>

</body>
</html>
