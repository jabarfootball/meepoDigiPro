<?php
include '../db.php';
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Admin Panel - MeepoDiGiPro</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50 flex">

<!-- Sidebar -->
<aside class="w-64 h-screen bg-gray-800 text-white p-6 flex flex-col justify-between">
  <div>
    <h2 class="text-2xl font-bold mb-6">Admin Panel</h2>
    <nav class="flex flex-col space-y-4">
      <a href="dashboard.php" class="hover:underline">Dashboard</a>
      <a href="manage_users.php" class="hover:underline">Manajemen User</a>
      <a href="manage_missions.php" class="hover:underline">Manajemen Misi</a>
      <a href="manage_referral.php" class="hover:underline">Referral</a>
      <a href="manage_withdraw.php" class="hover:underline">Withdraw</a>
      <a href="manage_deposit.php" class="hover:underline">Deposit</a>
      <a href="manage_products.php" class="hover:underline">Produk</a>
      <a href="settings.php" class="hover:underline">Pengaturan</a>
      <a href="logout.php" class="hover:underline text-red-400">Logout</a>
    </nav>
  </div>
  <p class="text-xs">MeepoDiGiPro Admin © <?= date('Y') ?></p>
</aside>

<!-- Content -->
<main class="flex-1 p-10">
  <h1 class="text-3xl font-bold mb-6">Selamat Datang Admin!</h1>

  <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    <div class="bg-white p-6 rounded shadow">
      <h2 class="text-gray-600 font-semibold">Total User</h2>
      <p class="text-3xl font-bold text-blue-500">150</p>
    </div>
    <div class="bg-white p-6 rounded shadow">
      <h2 class="text-gray-600 font-semibold">Total Produk</h2>
      <p class="text-3xl font-bold text-green-500">20</p>
    </div>
    <div class="bg-white p-6 rounded shadow">
      <h2 class="text-gray-600 font-semibold">Withdraw Pending</h2>
      <p class="text-3xl font-bold text-yellow-500">3</p>
    </div>
  </div>
</main>

</body>
</html>
