<?php
session_start();
include '../db.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$users = $conn->query("SELECT * FROM users ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Pengguna - Admin</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

<?php include 'sidebar.php'; ?>

<div class="main-content">
    <h1>Kelola Pengguna</h1>

    <table>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Saldo</th>
            <th>Level</th>
            <th>Misi Selesai</th>
            <th>Aksi</th>
        </tr>
        <?php while($u = $users->fetch_assoc()): ?>
        <tr>
            <td><?= $u['id'] ?></td>
            <td><?= htmlspecialchars($u['username']) ?></td>
            <td>Rp <?= number_format($u['saldo']) ?></td>
            <td><?= $u['level'] ?></td>
            <td><?= $u['missions_completed'] ?></td>
            <td>
                <a href="edit_user.php?id=<?= $u['id'] ?>">Edit</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

</div>

</body>
</html>
