<?php
include '../db.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$id = intval($_GET['id']);

// Update status withdraw
$conn->query("UPDATE withdraws SET status='rejected' WHERE id=$id");

// Refund saldo user
$w = $conn->query("SELECT * FROM withdraws WHERE id=$id")->fetch_assoc();
$conn->query("UPDATE users SET saldo = saldo + {$w['amount']} WHERE id={$w['user_id']}");

echo "<script>alert('Withdraw ditolak dan saldo dikembalikan!'); window.location='manage_withdraw.php';</script>";
