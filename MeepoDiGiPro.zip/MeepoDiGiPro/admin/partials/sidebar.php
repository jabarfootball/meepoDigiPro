<div class="sidebar">
    <h2>MeepoDiGiPro</h2>
    <ul>
        <li><a href="dashboard.php">🏠 Dashboard</a></li>
        <li><a href="manage_users.php">👥 Kelola Users</a></li>
        <li><a href="manage_missions.php">🎯 Kelola Misi</a></li>
        <li><a href="manage_products.php">🛒 Kelola Produk</a></li>
        <li><a href="manage_withdraw.php">💸 Tarik Dana</a></li>
        <li><a href="manage_referral.php">🔗 Referral</a></li>
        <li><a href="manage_theme.php">🎨 Tema Web</a></li>
        <li><a href="settings.php">⚙️ Pengaturan</a></li>
        <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
</div>

<div class="content">
