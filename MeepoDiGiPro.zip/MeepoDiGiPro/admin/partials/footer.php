</div> <!-- content -->
</div> <!-- wrapper -->
<footer class="footer">
    © <?= date('Y') ?> MeepoDiGiPro - Admin Panel
</footer>
</body>
</html>
