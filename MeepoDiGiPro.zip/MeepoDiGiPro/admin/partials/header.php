<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - MeepoDiGiPro</title>
    <link href="../assets/css/admin.css" rel="stylesheet">
</head>
<body class="dark-mode">

<div class="admin-wrapper">
