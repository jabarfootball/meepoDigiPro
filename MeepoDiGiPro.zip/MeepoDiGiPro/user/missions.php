<?php
session_start();
include '../db.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil misi yang belum diselesaikan
$missions = $conn->query("SELECT * FROM products 
    WHERE id NOT IN (SELECT product_id FROM missions_done WHERE user_id=$user_id)
    ORDER BY id DESC");

// Proses klaim misi
if (isset($_POST['claim'])) {
    $product_id = intval($_POST['product_id']);
    $reward = intval($_POST['reward']);
    $product_name = $conn->query("SELECT product_name FROM products WHERE id=$product_id")->fetch_assoc()['product_name'];
    $date = date('Y-m-d H:i:s');

    // Masukkan ke misi selesai
    $conn->query("INSERT INTO missions_done (user_id, product_id, product_name, reward, completed_at) VALUES ($user_id, $product_id, '$product_name', $reward, '$date')");

    // Tambahkan saldo user
    $conn->query("UPDATE users SET saldo = saldo + $reward WHERE id = $user_id");

    echo "<script>alert('Misi berhasil diklaim! Saldo bertambah.'); window.location='missions.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Misi Produk - MeepoDiGiPro</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="container">
    <h1>Daftar Misi</h1>

    <?php while($m = $missions->fetch_assoc()): ?>
        <div class="card">
            <h3><?= htmlspecialchars($m['product_name']) ?></h3>
            <p>Hadiah: Rp<?= number_format($m['reward']) ?></p>
            <form method="POST">
                <input type="hidden" name="product_id" value="<?= $m['id'] ?>">
                <input type="hidden" name="reward" value="<?= $m['reward'] ?>">
                <button type="submit" name="claim">Selesaikan Misi</button>
            </form>
        </div>
    <?php endwhile; ?>

    <br>
    <a href="dashboard.php" class="btn">Kembali</a>
</div>

</body>
</html>
