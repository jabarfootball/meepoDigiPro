<?php
session_start();
include '../db.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil data user
$user = $conn->query("SELECT * FROM users WHERE id = $user_id")->fetch_assoc();

// Handle request withdraw
if (isset($_POST['submit'])) {
    $amount = intval($_POST['amount']);
    $date = date('Y-m-d H:i:s');

    if ($amount <= 0 || $amount > $user['saldo']) {
        echo "<script>alert('Jumlah withdraw tidak valid!'); window.location='withdraw.php';</script>";
        exit;
    }

    if (empty($user['bank_name']) || empty($user['bank_account'])) {
        echo "<script>alert('Lengkapi data bank Anda di profil terlebih dahulu!'); window.location='profile.php';</script>";
        exit;
    }

    // Insert transaksi withdraw
    $conn->query("INSERT INTO withdraws (user_id, amount, bank_name, bank_account, status, created_at) VALUES ($user_id, $amount, '{$user['bank_name']}', '{$user['bank_account']}', 'pending', '$date')");

    // Kurangi saldo langsung (atau tunggu approve admin, tergantung aturanmu)
    $conn->query("UPDATE users SET saldo = saldo - $amount WHERE id=$user_id");

    echo "<script>alert('Permintaan withdraw dikirim! Tunggu konfirmasi admin.'); window.location='withdraw.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Withdraw Saldo - MeepoDiGiPro</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="container">
    <h1>Withdraw Saldo</h1>

    <form method="POST">
        <label>Jumlah Withdraw (Rp)</label><br>
        <input type="number" name="amount" required><br><br>

        <p><b>Akun Bank:</b> <?= htmlspecialchars($user['bank_name']) ?> | <?= htmlspecialchars($user['bank_account']) ?></p>

        <button type="submit" name="submit">Kirim Permintaan</button>
    </form>

    <br>
    <a href="dashboard.php" class="btn">Kembali</a>
</div>

</body>
</html>
