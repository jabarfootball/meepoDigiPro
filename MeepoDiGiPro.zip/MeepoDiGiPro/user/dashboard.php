<?php
include '../db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$user = $conn->query("SELECT * FROM users WHERE id=$user_id")->fetch_assoc();
$missions_completed = $user['missions_completed'];
$level = $user['level'];
$needed = $level * 5;
$progress = min(100, ($missions_completed / $needed) * 100);
$total_missions = $conn->query("SELECT COUNT(*) as total FROM missions WHERE status='aktif'")->fetch_assoc()['total'];

// Ambil news dummy
$news = [
    "🎉 Promo Cashback Besar untuk Member Baru!",
    "🚀 Update Misi Baru: Dapatkan Reward lebih banyak!",
    "🔥 Event Spesial: Top Up Bonus Saldo!",
];
?>

<?php
include '../db.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - MeepoDiGiPro</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 flex">

<!-- Sidebar -->
<aside class="w-64 h-screen bg-blue-600 text-white p-6 flex flex-col justify-between">
  <div>
    <h2 class="text-2xl font-bold mb-6">MeepoDiGiPro</h2>
    <nav class="flex flex-col space-y-4">
      <a href="dashboard.php" class="hover:underline">Dashboard</a>
      <a href="missions.php" class="hover:underline">Misi</a>
      <a href="referral.php" class="hover:underline">Referral</a>
      <a href="history.php" class="hover:underline">Riwayat</a>
      <a href="profile.php" class="hover:underline">Profil</a>
      <a href="logout.php" class="hover:underline text-red-400">Logout</a>
    </nav>
  </div>
  <p class="text-xs">MeepoDiGiPro © <?= date('Y') ?></p>
</aside>

<!-- Content -->
<main class="flex-1 p-10">
  <h1 class="text-3xl font-bold mb-6">Selamat Datang, <?= $_SESSION['username'] ?></h1>

  <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
    <div class="bg-white p-4 rounded shadow">
      <h2 class="text-sm font-semibold text-gray-600">Saldo</h2>
      <p class="text-2xl font-bold text-blue-500">Rp <?= number_format(10000) ?></p>
    </div>
    <div class="bg-white p-4 rounded shadow">
      <h2 class="text-sm font-semibold text-gray-600">Misi Selesai</h2>
      <p class="text-2xl font-bold text-green-500">5</p>
    </div>
    <div class="bg-white p-4 rounded shadow">
      <h2 class="text-sm font-semibold text-gray-600">Referral</h2>
      <p class="text-2xl font-bold text-yellow-500">2 Orang</p>
    </div>
    <div class="bg-white p-4 rounded shadow">
      <h2 class="text-sm font-semibold text-gray-600">Level</h2>
      <p class="text-2xl font-bold text-purple-500">Lv. 1</p>
    </div>
  </div>
</main>

</body>
</html>



<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - <?= htmlspecialchars($user['username']) ?></title>
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        /* Slider style */
        .slider-container {
            overflow: hidden;
            background: #3498db;
            color: white;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 20px;
            position: relative;
        }
        .slider-texts {
            white-space: nowrap;
            animation: slide 15s linear infinite;
        }
        @keyframes slide {
            0% { transform: translateX(100%); }
            100% { transform: translateX(-100%); }
        }
    </style>
</head>
<body>

<div class="dashboard-container">

    <!-- SLIDER NEWS -->
    <div class="slider-container">
        <div class="slider-texts">
            <?php foreach ($news as $item): ?>
                <span style="margin-right:50px;"><?= htmlspecialchars($item) ?></span>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- PROFILE CARD -->
    <div class="profile-card">
        <img src="<?= !empty($user['profile_picture']) ? $user['profile_picture'] : '../assets/images/default_profile.png' ?>" alt="Profile" class="profile-pic">
        <h2><?= htmlspecialchars($user['username']) ?></h2>
        <p>Level: <?= $level ?> | Saldo: Rp <?= number_format($user['saldo']) ?></p>

        <div class="progress-bar">
            <div class="progress" style="width: <?= $progress ?>%;"></div>
        </div>
        <small><?= $missions_completed ?>/<?= $needed ?> Misi untuk Level <?= $level + 1 ?></small>
    </div>

    <div class="missions-summary">
        <h3>📋 Misi Aktif: <?= $total_missions ?> Misi</h3>
        <a href="missions.php" class="btn">Lihat Misi ➔</a>
    </div>

    <div class="bottom-nav">
        <a href="dashboard.php">🏠 Beranda</a>
        <a href="missions.php">🎯 Misi</a>
        <a href="withdraw.php">💸 Tarik</a>
        <a href="deposit.php">➕ Deposit</a>
        <a href="history.php">📜 Riwayat</a>
        <a href="profile.php">👤 Akun</a>
    </div>
</div>

</body>
</html>
