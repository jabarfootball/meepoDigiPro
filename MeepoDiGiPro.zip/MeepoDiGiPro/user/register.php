<?php
session_start();
include '../db.php';

if (isset($_POST['register'])) {
    $username = $conn->real_escape_string($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $referred_by = $conn->real_escape_string($_POST['referred_by']);

    // Buat kode referral unik
    $referral_code = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'), 0, 6);

    // Cek kode referral valid (jika ada)
    if (!empty($referred_by)) {
        $check = $conn->query("SELECT id FROM users WHERE referral_code='$referred_by'");
        if ($check->num_rows == 0) {
            $error = "Kode referral tidak ditemukan!";
        }
    } else {
        $referred_by = NULL;
    }

    // Jika tidak ada error
    if (!isset($error)) {
        $conn->query("INSERT INTO users (username, password, referral_code, referred_by) 
                      VALUES ('$username', '$password', '$referral_code', ".($referred_by ? "'$referred_by'" : "NULL").")");

        // Beri bonus ke yang ngajak
        if ($referred_by) {
            $bonus = 1000; // contoh Rp 1.000
            $conn->query("UPDATE users SET saldo = saldo + $bonus WHERE referral_code='$referred_by'");

            $referrer = $conn->query("SELECT id FROM users WHERE referral_code='$referred_by'")->fetch_assoc();
            $referrer_id = $referrer['id'];
            $conn->query("INSERT INTO transactions (user_id, type, amount, description) 
                          VALUES ($referrer_id, 'referral', $bonus, 'Bonus Referral dari $username')");
        }

        echo "<script>alert('Registrasi berhasil!'); window.location='login.php';</script>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Register - MeepoDiGiPro</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="register-container">
    <h1>Daftar Akun</h1>

    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>

    <form method="POST">
        <input type="text" name="username" placeholder="Username" required><br><br>
        <input type="password" name="password" placeholder="Password" required><br><br>
        <input type="text" name="referred_by" placeholder="Kode Referral (Opsional)"><br><br>
        <button type="submit" name="register">Daftar</button>
    </form>

    <p>Sudah punya akun? <a href="login.php">Login</a></p>
</div>

</body>
</html>
