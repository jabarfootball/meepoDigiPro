<?php
include '../db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../user/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle upload foto
if (isset($_POST['update_profile'])) {
    $username = $conn->real_escape_string($_POST['username']);

    // Upload gambar (jika ada file baru)
    if (!empty($_FILES['profile_picture']['name'])) {
        $target_dir = "../assets/images/profiles/";
        $filename = basename($_FILES["profile_picture"]["name"]);
        $target_file = $target_dir . time() . "_" . $filename;
        move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file);

        // Update nama dan foto
        $query = "UPDATE users SET username='$username', profile_picture='$target_file' WHERE id=$user_id";
    } else {
        // Update nama saja
        $query = "UPDATE users SET username='$username' WHERE id=$user_id";
    }

    $conn->query($query);
    echo "<script>alert('Profil berhasil diupdate!'); window.location='profile.php';</script>";
}

// Ambil data user
$user = $conn->query("SELECT * FROM users WHERE id=$user_id")->fetch_assoc();
?>

<h2>Profil Saya</h2>

<form method="POST" enctype="multipart/form-data">
    <label>Username:</label><br>
    <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required><br><br>

    <label>Foto Profil:</label><br>
    <?php if (!empty($user['profile_picture'])): ?>
        <img src="<?= $user['profile_picture'] ?>" alt="Profile" width="100"><br><br>
    <?php endif; ?>
    <input type="file" name="profile_picture"><br><br>

    <button type="submit" name="update_profile">Update Profil</button>
</form>

<br>
<a href="dashboard.php">⬅️ Kembali ke Dashboard</a>
