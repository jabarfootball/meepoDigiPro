<?php
include '../db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
  header('Location: ../user/login.php');
  exit;
}

$user_id = $_SESSION['user_id'];
$product_id = intval($_GET['id']);

// Cek apakah sudah pernah beli
$check = $conn->query("SELECT * FROM user_products WHERE user_id=$user_id AND product_id=$product_id");
if ($check->num_rows > 0) {
  echo "<script>alert('Kamu sudah membeli produk ini!'); window.location='../user/dashboard.php';</script>";
  exit;
}

// Ambil produk
$product = $conn->query("SELECT * FROM products WHERE id=$product_id")->fetch_assoc();
if (!$product) {
  echo "<script>alert('Produk tidak ditemukan!'); window.location='../user/dashboard.php';</script>";
  exit;
}

// Tambahkan saldo user
$conn->query("UPDATE users SET saldo = saldo + {$product['diskon']} WHERE id=$user_id");

// Catat pembelian
$conn->query("INSERT INTO user_products (user_id, product_id) VALUES ($user_id, $product_id)");

// Catat transaksi
$conn->query("INSERT INTO transactions (user_id, type, amount, description) 
VALUES ($user_id, 'bonus', {$product['diskon']}, 'Diskon dari beli produk: {$product['nama']}')");

echo "<script>alert('Berhasil membeli produk! Diskon sudah ditambahkan ke saldo.'); window.location='../user/dashboard.php';</script>";
?>
