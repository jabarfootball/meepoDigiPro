<?php
session_start();
include '../db.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil semua transaksi user
$deposits = $conn->query("SELECT * FROM deposits WHERE user_id = $user_id ORDER BY created_at DESC");
$withdraws = $conn->query("SELECT * FROM withdraws WHERE user_id = $user_id ORDER BY created_at DESC");
$missions = $conn->query("SELECT * FROM missions_done WHERE user_id = $user_id ORDER BY completed_at DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Riwayat Aktivitas - MeepoDiGiPro</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="container">
    <h1>Riwayat Aktivitas</h1>

    <h2>Deposit</h2>
    <ul>
        <?php while($d = $deposits->fetch_assoc()): ?>
            <li>Rp<?= number_format($d['amount']) ?> - <?= htmlspecialchars($d['status']) ?> (<?= $d['created_at'] ?>)</li>
        <?php endwhile; ?>
    </ul>

    <h2>Withdraw</h2>
    <ul>
        <?php while($w = $withdraws->fetch_assoc()): ?>
            <li>Rp<?= number_format($w['amount']) ?> - <?= htmlspecialchars($w['status']) ?> (<?= $w['created_at'] ?>)</li>
        <?php endwhile; ?>
    </ul>

    <h2>Misi Selesai</h2>
    <ul>
        <?php while($m = $missions->fetch_assoc()): ?>
            <li><?= htmlspecialchars($m['product_name']) ?> - Rp<?= number_format($m['reward']) ?> (<?= $m['completed_at'] ?>)</li>
        <?php endwhile; ?>
    </ul>

    <br>
    <a href="dashboard.php" class="btn">Kembali</a>
</div>

</body>
</html>
