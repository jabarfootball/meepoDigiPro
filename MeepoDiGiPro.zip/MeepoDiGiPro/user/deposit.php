<?php
session_start();
include '../db.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil daftar bank admin
$banks = $conn->query("SELECT * FROM admin_banks");

// Handle request deposit
if (isset($_POST['submit'])) {
    $amount = intval($_POST['amount']);
    $bank_id = intval($_POST['bank_id']);
    $date = date('Y-m-d H:i:s');

    if ($amount <= 0) {
        echo "<script>alert('Jumlah deposit tidak valid!'); window.location='deposit.php';</script>";
        exit;
    }

    // Insert transaksi pending
    $conn->query("INSERT INTO deposits (user_id, bank_id, amount, status, created_at) VALUES ($user_id, $bank_id, $amount, 'pending', '$date')");

    echo "<script>alert('Permintaan deposit terkirim! Tunggu konfirmasi admin.'); window.location='deposit.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Deposit Saldo - MeepoDiGiPro</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="container">
    <h1>Deposit Saldo</h1>

    <form method="POST">
        <label>Jumlah Deposit (Rp)</label><br>
        <input type="number" name="amount" required><br><br>

        <label>Transfer ke Bank Admin</label><br>
        <select name="bank_id" required>
            <?php while($b = $banks->fetch_assoc()): ?>
                <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['bank_name']) ?> - <?= htmlspecialchars($b['bank_account']) ?></option>
            <?php endwhile; ?>
        </select><br><br>

        <button type="submit" name="submit">Kirim Permintaan</button>
    </form>

    <br>
    <a href="dashboard.php" class="btn">Kembali</a>
</div>

</body>
</html>
