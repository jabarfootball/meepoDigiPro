<?php
session_start();
include '../db.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Data referral
$user = $conn->query("SELECT * FROM users WHERE id=$user_id")->fetch_assoc();
$referrals = $conn->query("SELECT username, created_at FROM users WHERE referred_by='{$user['referral_code']}' ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Referral - MeepoDiGiPro</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="container">
    <h1>Program Referral</h1>

    <p>Link Referral Anda:</p>
    <input type="text" value="https://<?= $_SERVER['HTTP_HOST'] ?>/user/register.php?ref=<?= $user['referral_code'] ?>" readonly style="width:100%;">

    <h2>Referral Yang Bergabung</h2>
    <ul>
        <?php while($r = $referrals->fetch_assoc()): ?>
            <li><?= htmlspecialchars($r['username']) ?> (<?= $r['created_at'] ?>)</li>
        <?php endwhile; ?>
    </ul>

    <br>
    <a href="dashboard.php" class="btn">Kembali</a>
</div>

</body>
</html>
