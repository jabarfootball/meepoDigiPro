document.addEventListener('DOMContentLoaded', function () {
    const slider = document.querySelector('.slider-track');
    let scrollAmount = 0;

    function autoScroll() {
        scrollAmount += 1;
        if (scrollAmount >= slider.scrollWidth / 2) {
            scrollAmount = 0;
        }
        slider.scrollLeft = scrollAmount;
    }

    setInterval(autoScroll, 30);
});
